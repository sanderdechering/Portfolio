@extends('layout')

@section('title')
    Image Library | Sander Dechering
@endsection

@section('content')

    <div class="col-sm-12 col-md-8 offset-md-2 col-lg-4 offset-lg-4 my-4">
        <h2 class="my-5">Image Library</h2>
        <div class="row">
        </div>
    </div>

@endsection
